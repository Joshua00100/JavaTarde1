package _1_Exemplos;

public class concatenar {
    public static void main(String[] args) {
        int x=100;
        System.out.println(" A roupa custa = " + x + "reais");

}}
