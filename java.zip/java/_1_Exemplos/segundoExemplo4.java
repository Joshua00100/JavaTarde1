package _1_Exemplos;

public class segundoExemplo4
{
    public static void main(String[] args) {
        int a , b;
        double resultado;
        a = 5;
        b = 2;
        resultado = (double)a / b;
        System.out.println(resultado);
    }
}
