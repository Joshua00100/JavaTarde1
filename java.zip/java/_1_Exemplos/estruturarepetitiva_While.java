package _1_Exemplos;

import java.util.Scanner;

public class estruturarepetitiva_While {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();//5
        int soma = 0;
        while (x != 0){ // enquanto x for diferente de zero
            soma += x;
            //neste produto estou pegando oque esta sendo digitado
            // pelo usuario e inserido dentro da variavel da soma
            x = sc.nextInt();
        }
        System.out.println(soma);
        sc.close();

    }
}
