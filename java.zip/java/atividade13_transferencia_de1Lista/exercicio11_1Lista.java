package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio11_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("sensor de linha detecta operador?");
        String n1 = sc.nextLine();
        if (n1.equalsIgnoreCase("sim")) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }
}
