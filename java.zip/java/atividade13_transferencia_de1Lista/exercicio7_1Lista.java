package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio7_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o numero de defeitos do lote ");
        double n1 = sc.nextDouble();
        if (n1 >= 5.0) {
            System.out.println("lote reprovado");
        } else {
            System.out.println("lote aprovado");
        }
    }
}
