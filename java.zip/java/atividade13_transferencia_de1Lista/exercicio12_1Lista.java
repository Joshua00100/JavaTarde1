package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio12_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Qual a eficiencia de produçao");
        double n1 = sc.nextDouble();
        if (n1>=85) {
            System.out.println("Eficiencia aceitavel");
        }
        else {
            System.out.println("Manutençao recomendada");
        }
    }
}
