package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio4_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite quantos KG");
        double n1 = sc.nextDouble();
        if (n1 >= 5.0) {
            System.out.println("peça pesada");
        } else {
            System.out.println("peça leve");
        }
    }
}
