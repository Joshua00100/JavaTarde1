package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio6_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digitea produçao");
        double n1 = sc.nextDouble();
        if (n1 >= 100.0) {
            System.out.println("meta atingida");
        } else {
            System.out.println("produçao abaixo da meta");
        }
    }
}
