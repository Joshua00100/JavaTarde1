package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio15_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("difite a porcentagem de peças ");
        double n1 = sc.nextDouble();
        if (n1>=90) {
            System.out.println("Qualidade aceitavel");
        }
        else {
            System.out.println("qualidade abaixo do padrao");
        }
    }
}
