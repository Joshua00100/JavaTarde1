package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio14_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o numero de peças");
        double n1 = sc.nextDouble();
        if (n1>=0) {
            System.out.println("montagem em andamento");
        }
        else {
            System.out.println("Verificar o robo");
        }
    }
}
