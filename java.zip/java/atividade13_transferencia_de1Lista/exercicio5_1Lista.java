package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio5_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("digite a velocidade");
        double n1 = sc.nextDouble();
        if (n1 >= 120.0) {
            System.out.println("reduzir a velocidade");
        } else {
            System.out.println("velocidade dentro do limite");
        }
    }
}
