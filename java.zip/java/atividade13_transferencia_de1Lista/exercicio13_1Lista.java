package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio13_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a energia");
        double n1 = sc.nextDouble();
        if (n1>=200) {
            System.out.println("Energia solar suficiente");
        }
        else {
            System.out.println("Adicionar energia");
        }
    }
}
