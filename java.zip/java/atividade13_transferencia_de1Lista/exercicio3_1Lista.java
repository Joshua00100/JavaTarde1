package atividade13_transferencia_de1Lista;

import java.util.Scanner;

public class exercicio3_1Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a energia");
        double n1 = sc.nextDouble();
        if (n1 >= 50.0) {
            System.out.println("Robo iniciando a pintura");
        } else {
            System.out.println("Energia insuficiente, recarergar");
        }
    }
}
