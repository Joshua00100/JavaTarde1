package _01_estruturaSequencial;

import java.util.Scanner;

public class exercicio3 {

public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Digite o primeiro valor : ");
    int a = sc.nextInt();
    System.out.println("Digite o segundo valor: ");
    int b = sc.nextInt();
    System.out.println("Digite o terceiro valor; ");
    int c = sc.nextInt();
    System.out.println("Digite o quarto valor:");
    int d = sc.nextInt();
    int DIFERENCA = a * b - c * d;
    System.out.println("A DIFERENCA E:" + DIFERENCA);
    sc.close();
}
}