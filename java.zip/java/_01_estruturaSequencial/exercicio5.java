package _01_estruturaSequencial;

import java.util.Scanner;

public class exercicio5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o codigo da primeirapeca : ");
        double a = sc.nextDouble();
        System.out.printf("Digite o codigo : ");
        double b = sc.nextDouble();
        System.out.printf("Digite o valorUnitario : ");
        double c = sc.nextDouble();
        System.out.printf("Digite o codigo da segundapeca : ");
        double d = sc.nextDouble();
        System.out.printf("Digite o codigo : ");
        double e = sc.nextDouble();
        System.out.printf("Digite o valorUnitario: ");
        double f = sc.nextDouble();
        double total = (b*c)+(e*f);
        System.out.printf("VALOR A PAGAR: R$%.2f/n" , total);
        sc.close();
    }
}