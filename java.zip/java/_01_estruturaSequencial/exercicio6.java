package _01_estruturaSequencial;

import java.util.Scanner;

public class exercicio6 {


    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Digite os valores de A, B e C");
    double A = sc.nextDouble();
    double B = sc.nextInt();
    double C = sc.nextDouble();
    double pi = 3.14;
    double triangulo = (A * C) / 2.0;
    double circulo = pi * C * C;
    double trapezio = ((A + B) * C) / 2.0;
    double quadrado = B * B;
    double retangulo = A * B;
    System.out.println("Triangulo:%.3f/n, triangulo");
    System.out.println("Circulo:%.3f/n, circulo ");
    System.out.println("Trapezio:%.3f/n, trapezio");
    System.out.println("Retangulo:%.3f/n, retangulo");
    sc.close();

}
}
