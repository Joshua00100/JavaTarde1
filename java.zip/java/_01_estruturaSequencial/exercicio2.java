package _01_estruturaSequencial;

import java.util.Scanner;

public class exercicio2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a area do circulo: ");
        double raio = sc.nextDouble();
        double area = 3.14 * raio * raio;
        System.out.printf("A area do circulo e: %.4f%n" , area);
        sc.close();
    }
}