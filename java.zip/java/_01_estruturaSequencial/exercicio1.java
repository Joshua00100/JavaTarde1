package _01_estruturaSequencial;

import java.util.Scanner;

public class exercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Digite o primeiro numero: ");
        double x = sc.nextDouble();
        System.out.println();
        System.out.println("Digite o segundo numero: ");
        double y = sc.nextDouble();
        System.out.println();
        double soma = x + y;
        System.out.println("SOMA= " + soma);
        sc.close();


    }
}

