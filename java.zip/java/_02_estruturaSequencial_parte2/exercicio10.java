package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Digite sua altura (em metros): ");
        double altura = sc.nextDouble();
        double pesoIdeal = 72.7 * altura - 58;
        System.out.printf("Seu peso ideal e: 5.2f kg%n" , pesoIdeal);
        sc.close();
    }
}
