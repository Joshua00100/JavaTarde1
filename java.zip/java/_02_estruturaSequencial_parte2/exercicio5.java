package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o lado do quadrado ");
        double lado = sc.nextDouble();
        double area = lado * lado;
        double perimetro = 4 * lado;
        System.out.printf("Area do quadrado: %.2f%n" , area);
        System.out.printf("Perimetro do quadrado: %.2f%n " , perimetro);
        sc.close();
    }
}
