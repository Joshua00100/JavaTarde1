package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite a base maior do trapezio: ");
        double baseMaior = sc.nextDouble();
        System.out.printf("Digite a base menor do trapezio: ");
        double baseMenor = sc.nextDouble();
        System.out.printf("Digite a altura do trapezio: ");
        double altura = sc.nextDouble();
        double area = ((baseMaior + baseMenor) * altura) / 2;
        System.out.printf("A area do trapezio e: %.2f%n" , area);
        sc.close();

    }
}
