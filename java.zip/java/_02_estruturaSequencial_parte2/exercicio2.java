package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite as horas: ");
        double horas = sc.nextDouble();
        double minutos = horas * 60;
        System.out.println(horas + "horas equivalem a " + minutos + "minutos" );
        sc.close();

    }
}
