package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o valor do produto: ");
        double valor = sc.nextDouble();
        double desconto = valor * 0.15;
        double valorcomDesconto = sc.nextDouble();
        System.out.printf("O valor com  15%% desconto e: R$ %.2f%n", valorcomDesconto);
        sc.close();
    }
}
