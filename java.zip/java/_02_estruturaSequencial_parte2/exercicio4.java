package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a primeira nota (peso 3): ");
        double nota1 = sc.nextDouble();
        System.out.println("Digite a segunda nota (peso2): ");
        double nota2 = sc.nextDouble();
        double mediaPonderada = (nota1 * 3 + nota2 * 2) / (3 + 2);
        System.out.printf("A media ponderada e: %.2f%n", mediaPonderada);
        sc.close();
    }
    }
