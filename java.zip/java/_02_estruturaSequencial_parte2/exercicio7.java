package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a quantidade de quilometros pecorridos:");
        double kmPercorridos = sc.nextDouble();
        System.out.println("Digite a quantidade de litro de combustivel consumidos:");
        double litrosConsumidos = sc.nextDouble();
        if (litrosConsumidos != 0) {
            double consumoMedio = kmPercorridos / litrosConsumidos;
            System.out.printf("O consumo medio do carro e: %.2f km/l%n", consumoMedio);
        } else {
            System.out.println("Erro: quantidade de litros consumidos nao pode ser zero.");
            sc.close();
        }
    }
}
