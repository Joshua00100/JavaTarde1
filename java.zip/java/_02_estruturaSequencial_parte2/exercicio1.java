package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a sua idade: ");
        int idade = sc.nextInt();
        int diasVividos = idade * 365;
        System.out.println("Voce ja viveu aproximadamente " + diasVividos + "dias");

    }
}
