package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite o valor da sua compra: ");
        double valorCompra = sc.nextDouble();
        double parcela = valorCompra / 3;
        System.out.printf("O valor a ser pago em 3 parcelas iguais e: R$ %.2f%n" , parcela);
        sc.close();
    }
}
