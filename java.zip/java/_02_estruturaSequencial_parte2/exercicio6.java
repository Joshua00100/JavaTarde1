package _02_estruturaSequencial_parte2;

import java.util.Scanner;

public class exercicio6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o valor do deposito: R$");
        double deposito = sc.nextDouble();
        System.out.println("Digite a taxa de juros mensal (%):");
        double taxaJuros = sc.nextDouble();
        double rendimento = deposito * (taxaJuros / 100);
        System.out.printf("O rendimento apos um mes sera: R$ %.2f%n", rendimento);
        sc.close();

    }
}
