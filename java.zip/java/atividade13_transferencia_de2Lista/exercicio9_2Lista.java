package atividade13_transferencia_de2Lista;

import java.util.Scanner;

public class exercicio9_2Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o índice de defeito do lote (%):");
        double indice = sc.nextDouble();

        if (indice > 10) {
            System.out.println("Acionar alerta");
        } else {
            System.out.println("Lote aprovado");
        }

        sc.close();
    }
    }
