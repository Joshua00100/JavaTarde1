package atividade13_transferencia_de2Lista;

import java.util.Scanner;

public class exercicio3_2Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a porcentagem de energia da máquina:");
        int energia = sc.nextInt();

        if (energia < 30) {
            System.out.println("Modo econômico");
        } else if (energia <= 70) {
            System.out.println("Modo normal");
        } else {
            System.out.println("Modo turbo");
        }

        sc.close();
    }
}
