package atividade13_transferencia_de2Lista;

import java.util.Scanner;

public class exercicio8_2Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a quantidade de material restante (%):");
        int material = sc.nextInt();

        if (material < 20) {
            System.out.println("Trocar material");
        } else {
            System.out.println("Continuar impressão");
        }

        sc.close();
    }
}
