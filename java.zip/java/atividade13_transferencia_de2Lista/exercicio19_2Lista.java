package atividade13_transferencia_de2Lista;

import java.util.Scanner;

public class exercicio19_2Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o valor do pH:");
        double ph = sc.nextDouble();

        if (ph < 7) {
            System.out.println("Ácido");
        } else if (ph == 7) {
            System.out.println("Neutro");
        } else {
            System.out.println("Básico");
        }

        sc.close();
    }
}
