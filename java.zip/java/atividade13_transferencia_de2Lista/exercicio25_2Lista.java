package atividade13_transferencia_de2Lista;

import java.util.Scanner;

public class exercicio25_2Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a intensidade elétrica (A):");
        int intensidade = sc.nextInt();

        if (intensidade < 100) {
            System.out.println("Intensidade fraca");
        } else if (intensidade <= 200) {
            System.out.println("Intensidade média");
        } else {
            System.out.println("Intensidade forte");
        }

        sc.close();
    }
}
