package atividade13_transferencia_de2Lista;

import java.util.Scanner;

public class exercicio23_2Lista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o percentual de tráfego suspeito (%):");
        int trafego = sc.nextInt();

        if (trafego > 70) {
            System.out.println("Bloquear acesso");
        } else if (trafego >= 30) {
            System.out.println("Alerta");
        } else {
            System.out.println("Tráfego normal");
        }

        sc.close();
    }
}
