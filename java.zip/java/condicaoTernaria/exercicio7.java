package condicaoTernaria;

import java.util.Scanner;

public class exercicio7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o salário do funcionário: R$ ");
        double salario = sc.nextDouble();

        double imposto = (salario > 5000) ? salario * 0.20 : salario * 0.10;

        System.out.printf("O imposto a ser pago é: R$ %.2f%n", imposto);

        sc.close();
    }
}
