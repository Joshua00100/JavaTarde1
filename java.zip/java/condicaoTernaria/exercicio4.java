package condicaoTernaria;

import java.util.Scanner;

public class exercicio4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a temperatura em Celsius: ");
        double temperatura = sc.nextDouble();

        String resultado = (temperatura < 18) ? "Frio" : "Quente";

        System.out.println(resultado);

        sc.close();
    }
}
