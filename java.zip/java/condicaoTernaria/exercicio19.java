package condicaoTernaria;

import java.util.Scanner;

public class exercicio19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o número de horas trabalhadas: ");
        int horas = sc.nextInt();

        System.out.print("Digite o valor por hora: R$ ");
        double valorHora = sc.nextDouble();

        double salario = horas * valorHora;

        String resultado = (salario > 2000) ? "Salário bom" : "Salário ruim";

        System.out.println(resultado);

        sc.close();
    }
}
