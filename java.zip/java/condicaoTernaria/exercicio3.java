package condicaoTernaria;

import java.util.Scanner;

public class exercicio3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

                System.out.print("Digite a idade: ");
                int idade = sc.nextInt();

                String resultado = (idade >= 16) ? "Pode votar" : "Não pode votar";

                System.out.println(resultado);

                sc.close();
    }
}
