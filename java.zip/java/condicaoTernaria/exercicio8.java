package condicaoTernaria;

import java.util.Scanner;

public class exercicio8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a idade: ");
        int idade = sc.nextInt();

        String categoria = (idade < 12) ? "Infantil" : (idade <= 18) ? "Juvenil" : "Adulto";

        System.out.println("Categoria: " + categoria);

        sc.close();
    }
}
