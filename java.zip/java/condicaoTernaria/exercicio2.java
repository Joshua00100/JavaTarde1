package condicaoTernaria;

import java.util.Scanner;

public class exercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite um número inteiro: ");
        int numero = sc.nextInt();

        String resultado = (numero >= 0) ? "Positivo" : "Negativo";

        System.out.println(resultado);

        sc.close();
    }
}
