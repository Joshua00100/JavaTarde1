package condicaoTernaria;

import java.util.Scanner;

public class exercicio18 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o primeiro número inteiro: ");
        int num1 = sc.nextInt();

        System.out.print("Digite o segundo número inteiro: ");
        int num2 = sc.nextInt();

        String resultado = (num1 == num2) ? "Números iguais" : (num1 > num2 ? num1 + " é maior" : num2 + " é maior");

        System.out.println(resultado);

        sc.close();
    }
}
