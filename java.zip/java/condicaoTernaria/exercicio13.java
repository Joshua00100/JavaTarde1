package condicaoTernaria;

import java.util.Scanner;

public class exercicio13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o salário: R$ ");
        double salario = sc.nextDouble();

        String resultado = (salario > 3000) ? "Salário alto" : "Salário baixo";

        System.out.println(resultado);

        sc.close();
    }
}
