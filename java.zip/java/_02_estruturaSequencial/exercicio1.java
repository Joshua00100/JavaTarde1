package _02_estruturaSequencial;

import java.util.Scanner;

public class exercicio1 {

public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Digite o primeiro numero");
    int x = sc.nextInt();
    System.out.println("Digite o segundo numero");
    int y = sc.nextInt();
    int soma = x + y;
    System.out.println("Soma = " + soma);
    sc.close();

    }
}