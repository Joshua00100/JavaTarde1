package _02_estruturaSequencial;

import java.util.Scanner;

public class exercicio6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a temperatura em Celsius:");
        double c = sc.nextDouble();
        double F = (c * 9/5)+32;
        System.out.println("a temperatura e:"+F);
        sc.close();
    }
}
