package _02_estruturaSequencial;

import java.util.Scanner;

public class exercicio4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a base do triangulo");
        double base = sc.nextDouble();
        System.out.println("Digite a altura do trangulo");
        double altura = sc.nextDouble();
        double calculo = (base * altura)/ 2 ;
        System.out.println("O valor de sua area e: "+ calculo);
        sc.close();
    }
}
