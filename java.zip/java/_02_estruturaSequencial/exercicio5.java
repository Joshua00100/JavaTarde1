package _02_estruturaSequencial;

import java.util.Scanner;

public class exercicio5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o valor do salario: ");
        double x = sc.nextDouble();
        double calculo = (x*10)/100;
        double soma = x+calculo;
        System.out.println("O valor do seu salario com seu aumento e: " + soma);
    }
}
