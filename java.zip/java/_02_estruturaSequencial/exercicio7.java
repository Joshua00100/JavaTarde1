package _02_estruturaSequencial;

import java.util.Scanner;

public class exercicio7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a quantidade de dias: ");
        int x = sc.nextInt();
        int calculo = x * 24;
        System.out.println("Convertido em horas: " + calculo);
        sc.close();



    }
}
