package atividade15_While;

import java.util.Scanner;

public class atividade9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double consumoHora = 1000;
        double aumento = 0.10;
        int hora = 1;
        int totalHoras = 5;
        double totalConsumido = 0;
        while (hora <= totalHoras) {
            System.out.println("Hora " + hora + ": consumo = " + consumoHora + " watts");
            totalConsumido += consumoHora;
            consumoHora *= (1 + aumento);
            hora++;
        }

        System.out.println("\nConsumo total após " + totalHoras + " horas = " + totalConsumido + " watts");
    }
}

