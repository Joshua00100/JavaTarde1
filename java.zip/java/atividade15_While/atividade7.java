package atividade15_While;

import java.util.Scanner;

public class atividade7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int velocidade = 0;
        int incremento = 100;
        int velocidadeMaxima = 1000;
        System.out.println("Iniciando monitoramento da máquina...");
        while (velocidade < velocidadeMaxima) {
            velocidade += incremento; // Acelera a máquina
            System.out.println("Após 2 minutos: velocidade = " + velocidade + " RPM");
        }
        System.out.println("Velocidade máxima atingida: " + velocidade + " RPM");
        System.out.println("Encerrando monitoramento.");

    }
}
