package atividade15_While;

import java.util.Scanner;

public class atividade5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pressao = 0;
        while (pressao<=119){
            System.out.println("Pressao : " + pressao );
            pressao +=1;

        }
        System.out.println("Pressao atingida " +pressao);

    }
}
