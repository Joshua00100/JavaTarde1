package atividade15_While;

import java.util.Scanner;

public class atividade6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int tempoPorPeca = 60;
        int pecasProduzidas = 0;
        int tempoTotal = 0;

        while (pecasProduzidas < 10) {
            tempoTotal += tempoPorPeca;
            System.out.println("Peça " + (pecasProduzidas + 1) + " produzida em " + tempoPorPeca + " segundos");
            tempoPorPeca -= 10;
            if (tempoPorPeca < 0) {
                tempoPorPeca = 0;
            }
            pecasProduzidas++;
        }

        System.out.println("Tempo total para produzir 10 peças: " + tempoTotal + " segundos");
    }
}
