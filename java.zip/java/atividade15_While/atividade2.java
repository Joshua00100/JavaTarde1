package atividade15_While;

import java.util.Scanner;

public class atividade2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int horas = 0;
        double somaTemperaturas = 0.0;

        while (horas < 24) {
            System.out.print("Digite a temperatura da hora " + (horas + 1) + ": ");
            double temperatura = scanner.nextDouble();
            somaTemperaturas += temperatura;
            horas++;
        }

        double media = somaTemperaturas / 24;
        System.out.printf("A média de temperatura das 24 horas é: %.2f\n", media);

        scanner.close();
    }
}
