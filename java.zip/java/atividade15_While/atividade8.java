package atividade15_While;

import java.util.Scanner;

public class atividade8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pecasProduzidas = 0;
        int falhas = 0;
        int totalPecas = 10000;
        int limiteFalhas = 50;
        int intervalo = 500;
        while (pecasProduzidas < totalPecas && falhas < limiteFalhas) {
            pecasProduzidas += intervalo;
            falhas += (int)(Math.random() * 6);
            if (falhas > limiteFalhas) {
                falhas = limiteFalhas;
            }
            System.out.println("Peças produzidas: " + pecasProduzidas + " | Falhas: " + falhas);
            if (falhas >= limiteFalhas) {
                System.out.println("⚠️ Limite de falhas atingido! Produção interrompida.");
                break;
            }
        }

        System.out.println("Produção finalizada com " + falhas + " falhas em " + pecasProduzidas + " peças.");
    }
}

