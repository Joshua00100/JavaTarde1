package atividade15_While;

import java.util.Scanner;

public class atividade3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int horasTrabalhadas = 0;
        int producaoPorHora = 50;
        int producaoTotal = 0;

        while (horasTrabalhadas < 8) {
            producaoTotal += producaoPorHora;  // adiciona a produção da hora
            horasTrabalhadas++;
            System.out.println("Hora " + horasTrabalhadas + ": Produção acumulada = " + producaoTotal + " unidades");
        }

        System.out.println("Produção total após 8 horas: " + producaoTotal + " unidades");

    }
}
