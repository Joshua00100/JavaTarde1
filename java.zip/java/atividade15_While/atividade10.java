package atividade15_While;

import java.util.Scanner;

public class atividade10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite ENTER para iniciar o programa: ");
        scanner.nextLine();
        int falhas = 0;
        while (falhas < 5) {
            System.out.println("Falhas detectadas: contagem" + falhas + 1);
            falhas++;
            System.out.println("Sistema desligado apos " + falhas + "Falhas consecutivas ");
        }

    }
}
