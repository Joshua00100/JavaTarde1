package atividade15_While;

import java.util.Scanner;

public class atividade1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int pecasProduzidas = 0;

        while (pecasProduzidas < 100) {
            pecasProduzidas++;
            System.out.println("Peça número: " + pecasProduzidas);
        }

        System.out.println("Produção finalizada: 100 peças produzidas.");
    }
}
