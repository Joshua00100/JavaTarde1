package atividade15_While;

import java.util.Scanner;

public class atividade4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int estoque = 500;

        while (estoque >= 100) {
            System.out.println("Estoque atual: " + estoque + " unidades");
            estoque -= 20;
        }

        System.out.println("Estoque baixo! Estoque final: " + estoque + " unidades");
    }
}
