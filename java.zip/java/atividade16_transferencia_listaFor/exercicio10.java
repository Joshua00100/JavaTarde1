package atividade16_transferencia_listaFor;

import java.util.Random;

public class exercicio10 {
    public static void main(String[] args) {
        Random random = new Random();
        int totalEmbalagens = 100;
        int[] resultados = new int[totalEmbalagens];
        int aprovadas = 0;
        int limiteAprovacao = 80;
        for (int i = 0; i < totalEmbalagens; i++) {
            resultados[i] = random.nextInt(101);
            if (resultados[i] >= limiteAprovacao) {
                aprovadas++;
            }
        }
        double porcentagemAprovadas = ((double) aprovadas / totalEmbalagens) * 100;
        System.out.print("Resultados dos testes de qualidade (amostra): [");
        for (int i = 0; i < 20; i++) {
            System.out.print(resultados[i]);
            if (i < 19) System.out.print(", ");
        }
        System.out.println(", ...]");
        System.out.printf("Total aprovado: %.2f%%\n", porcentagemAprovadas);
    }
}
