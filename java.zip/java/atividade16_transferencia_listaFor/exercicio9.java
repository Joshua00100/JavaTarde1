package atividade16_transferencia_listaFor;

import java.util.Random;

public class exercicio9 {
    public static void main(String[] args) {
        Random random = new Random();
        int produtos = 10;
        int[] previsaoDemanda = new int[produtos];
        int soma = 0;
        for (int i = 0; i < produtos; i++) {
            previsaoDemanda[i] = 1000 + random.nextInt(1001);
            soma += previsaoDemanda[i];
        }
        double media = (double) soma / produtos;
        System.out.print("Previsão de demanda para 10 produtos: [");
        for (int i = 0; i < produtos; i++) {
            System.out.print(previsaoDemanda[i]);
            if (i < produtos - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.printf("Previsão média de vendas: %.2f unidades\n", media);
    }
}
