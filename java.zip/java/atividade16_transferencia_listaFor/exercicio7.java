package atividade16_transferencia_listaFor;

import java.util.Random;

public class exercicio7 {
    public static void main(String[] args) {
        Random random = new Random();
        int totalSoldagens = 50;
        int[] tempos = new int[totalSoldagens];
        int soma = 0;
        int limite = 40;
        boolean excedeuLimite = false;
        for (int i = 0; i < totalSoldagens; i++) {
            tempos[i] = 25 + random.nextInt(21);
            soma += tempos[i];
            if (tempos[i] > limite) {
                excedeuLimite = true;
            }
        }
        double media = (double) soma / totalSoldagens;
        System.out.print("Tempos de soldagem: [");
        for (int i = 0; i < totalSoldagens; i++) {
            System.out.print(tempos[i]);
            if (i < totalSoldagens - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.printf("Tempo médio: %.2f minutos\n", media);

        if (excedeuLimite) {
            System.out.println(" Atenção: Houve soldagens que excederam o limite de " + limite + " minutos!");
        } else {
            System.out.println(" Nenhuma soldagem excedeu o limite de " + limite + " minutos.");

        }
    }
}
