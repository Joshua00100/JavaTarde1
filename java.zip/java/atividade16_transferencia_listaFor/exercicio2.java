package atividade16_transferencia_listaFor;

import java.util.Random;

public class exercicio2 {
    public static void main(String[] args) {
        Random random = new Random();
        int minutos = 12 * 60;
        int[] temperaturas = new int[minutos];
        int soma = 0;
        for (int i = 0; i < minutos; i++) {
            temperaturas[i] = 300 + random.nextInt(151);
            soma += temperaturas[i];
        }
        double media = (double) soma / minutos;
        System.out.print("Temperaturas registradas (amostra): [");
        for (int i = 0; i < 20; i++) {
            System.out.print(temperaturas[i]);
            if (i < 19) {
                System.out.print(", ");
            }
        }
        System.out.println(", ...]");
        System.out.printf("Média de temperatura durante as 12h: %.2f°C\n", media);
    }
}
