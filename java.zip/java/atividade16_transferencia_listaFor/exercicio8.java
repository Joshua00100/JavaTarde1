package atividade16_transferencia_listaFor;

import java.util.Random;

public class exercicio8 {
    public static void main(String[] args) {
        Random random = new Random();
        int totalMaquinas = 20;
        int[] tempoOperacao = new int[totalMaquinas];
        int somaOperacao = 0;
        for (int i = 0; i < totalMaquinas; i++) {
            tempoOperacao[i] = 200 + random.nextInt(301);
            somaOperacao += tempoOperacao[i];
        }
        System.out.print("Tempo de operação das máquinas: [");
        for (int i = 0; i < totalMaquinas; i++) {
            System.out.print(tempoOperacao[i]);
            if (i < totalMaquinas - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.println("Total de horas de operação: " + somaOperacao + " horas");
    }
}
